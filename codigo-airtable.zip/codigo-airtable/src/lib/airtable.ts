// src/lib/airtable.ts
// -----------------------------------------------------------------------------
// Capa de acceso a Airtable. SOLO se ejecuta del lado del servidor.
// El token (AIRTABLE_TOKEN) nunca llega al navegador.
//
// IDs reales de la base "Gestion clinica prueba con claude", ya validados:
//   Base ...................... appwTORPJtShnwxLA
//   Tabla Pacientes ........... tbl0yxGXUCl3j6O7U
//   Tabla ASIGNACION EN SALA .. tblqZZXysY5JAzPkm
// -----------------------------------------------------------------------------

const BASE_ID = "appwTORPJtShnwxLA";

const TABLES = {
  pacientes: "tbl0yxGXUCl3j6O7U",
  asignacion: "tblqZZXysY5JAzPkm",
};

// --- Campos de la tabla Pacientes ---
const PACIENTE_FIELDS = {
  nombre: "fldT6jJ3rNVMihhHM",      // Nombre Completo (campo primario)
  dni: "fldCMZ628lSnCtCxP",         // ID (DNI)
  genero: "fld9zF8b7uShu4VNJ",      // Género
  turno: "fldpZrYuSUVdlC7RM",       // TURNO (A/B/C, viene del paciente)
  frecuencia: "fld0BbHwfTTOOqMLy",  // FRECUENCIA (ACTIVO / FALLECIDO / TRASLADO...)
  filtro: "fldL4HczuHElwZ7zX",      // Filtro asignado
};

// --- Campos de la tabla ASIGNACION EN SALA ---
const ASIGNACION_FIELDS = {
  fecha: "fldoNyAk1oJkuO3s6",            // FECHA (dateTime, campo primario)
  paciente: "fld3LTynAo41VG07I",        // NOMBRE COMPLETO DEL PACIENTE (link)
  piso: "fldV4YTtdnEIEyrG9",            // PISO (singleSelect)
  silla: "fldnzYy2x8kz2aOUo",           // SILLA (singleSelect)
  turnoApp: "fldAsMvyiowUp6V23",        // TURNO ASIGNADO (App) (singleSelect A/B/C) -- creado por nosotros
  comentario: "fldw5avfCXdiKRGax",      // COMENTARIO (texto)
  nombreLookup: "fldVTOXDEf3L4tRvF",    // Nombre Completo (from Paciente) -- lookup, solo lectura
};

const API = "https://api.airtable.com/v0";

function token(): string {
  const t = process.env.AIRTABLE_TOKEN;
  if (!t) {
    throw new Error(
      "Falta la variable de entorno AIRTABLE_TOKEN. Configúrala en Firebase App Hosting / Google Cloud."
    );
  }
  return t;
}

function headers() {
  return {
    Authorization: `Bearer ${token()}`,
    "Content-Type": "application/json",
  };
}

export interface Paciente {
  id: string;       // recordId de Airtable
  nombre: string;
  dni: string;
  turno: string;    // A/B/C que trae el paciente (referencia)
  filtro: string;
}

// Tipo crudo mínimo de la respuesta de Airtable, para evitar `any`.
interface AirtableRecord {
  id: string;
  fields: Record<string, unknown>;
}
interface AirtableListResponse {
  records: AirtableRecord[];
  offset?: string;
}

// Convierte un valor de singleSelect (objeto {name} o string) a string plano.
function selectName(v: unknown): string {
  if (!v) return "";
  if (typeof v === "string") return v;
  if (typeof v === "object" && v !== null && "name" in v) {
    return String((v as { name: unknown }).name ?? "");
  }
  return "";
}

/**
 * Lee los pacientes ACTIVOS de la tabla Pacientes.
 * Filtramos por FRECUENCIA = "ACTIVO" para no mostrar fallecidos ni trasladados.
 * Maneja paginación (la tabla tiene ~1.200 registros).
 */
export async function getPacientesActivos(): Promise<Paciente[]> {
  const pacientes: Paciente[] = [];
  let offset: string | undefined;

  const fieldsParam = [
    PACIENTE_FIELDS.nombre,
    PACIENTE_FIELDS.dni,
    PACIENTE_FIELDS.turno,
    PACIENTE_FIELDS.frecuencia,
    PACIENTE_FIELDS.filtro,
  ]
    .map((f) => `fields[]=${encodeURIComponent(f)}`)
    .join("&");

  // filterByFormula: solo registros cuya FRECUENCIA sea exactamente "ACTIVO".
  const formula = encodeURIComponent(`{FRECUENCIA }="ACTIVO"`);

  do {
    const url =
      `${API}/${BASE_ID}/${TABLES.pacientes}` +
      `?${fieldsParam}&filterByFormula=${formula}&pageSize=100` +
      (offset ? `&offset=${offset}` : "");

    const res = await fetch(url, { headers: headers(), cache: "no-store" });
    if (!res.ok) {
      throw new Error(`Airtable (pacientes) respondió ${res.status}: ${await res.text()}`);
    }
    const data = (await res.json()) as AirtableListResponse;

    for (const rec of data.records) {
      const nombre = String(rec.fields[PACIENTE_FIELDS.nombre] ?? "").trim();
      if (!nombre) continue;
      pacientes.push({
        id: rec.id,
        nombre,
        dni: String(rec.fields[PACIENTE_FIELDS.dni] ?? ""),
        turno: selectName(rec.fields[PACIENTE_FIELDS.turno]),
        filtro: selectName(rec.fields[PACIENTE_FIELDS.filtro]),
      });
    }
    offset = data.offset;
  } while (offset);

  pacientes.sort((a, b) => a.nombre.localeCompare(b.nombre, "es"));
  return pacientes;
}

export interface NuevaAsignacion {
  pacienteId: string;   // recordId del paciente elegido
  piso: string;         // ej. "2A"
  silla: string;        // ej. "7"
  turno: "A" | "B" | "C";
  comentario?: string;
}

/**
 * Crea un registro en ASIGNACION EN SALA vinculando el paciente.
 * Devuelve el id del registro creado.
 */
export async function crearAsignacion(a: NuevaAsignacion): Promise<{ id: string }> {
  const url = `${API}/${BASE_ID}/${TABLES.asignacion}`;

  const fields: Record<string, unknown> = {
    [ASIGNACION_FIELDS.fecha]: new Date().toISOString(),
    [ASIGNACION_FIELDS.paciente]: [a.pacienteId], // los links van como array de recordIds
    [ASIGNACION_FIELDS.piso]: a.piso,
    [ASIGNACION_FIELDS.silla]: a.silla,
    [ASIGNACION_FIELDS.turnoApp]: a.turno,
  };
  if (a.comentario && a.comentario.trim()) {
    fields[ASIGNACION_FIELDS.comentario] = a.comentario.trim();
  }

  const res = await fetch(url, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify({ records: [{ fields }], typecast: true }),
  });

  if (!res.ok) {
    throw new Error(`Airtable (crear asignación) respondió ${res.status}: ${await res.text()}`);
  }
  const data = (await res.json()) as { records: AirtableRecord[] };
  return { id: data.records[0]?.id ?? "" };
}

// Opciones reales de los desplegables, ya leídas de tu base.
export const PISOS = ["2A", "2B", "2C", "2D", "2E", "3A", "3B", "3C", "3D", "3E", "4A", "4B", "4C"];
export const TURNOS: Array<"A" | "B" | "C"> = ["A", "B", "C"];
