// src/app/asignar/page.tsx
// Página: Asignación de paciente a silla.
// La enfermera busca al paciente (autocompletado), elige piso/silla/turno y registra.
// El registro se guarda en Airtable (tabla ASIGNACION EN SALA) vía /api/asignar.
"use client";

import { useEffect, useMemo, useState } from "react";

interface Paciente {
  id: string;
  nombre: string;
  dni: string;
  turno: string;
  filtro: string;
}

const PISOS = ["2A", "2B", "2C", "2D", "2E", "3A", "3B", "3C", "3D", "3E", "4A", "4B", "4C"];
const TURNOS = ["A", "B", "C"] as const;

export default function AsignarPage() {
  const [pacientes, setPacientes] = useState<Paciente[]>([]);
  const [cargando, setCargando] = useState(true);
  const [errorCarga, setErrorCarga] = useState("");

  const [busqueda, setBusqueda] = useState("");
  const [seleccionado, setSeleccionado] = useState<Paciente | null>(null);
  const [piso, setPiso] = useState("");
  const [silla, setSilla] = useState("");
  const [turno, setTurno] = useState<"A" | "B" | "C" | "">("");
  const [comentario, setComentario] = useState("");

  const [enviando, setEnviando] = useState(false);
  const [mensaje, setMensaje] = useState<{ tipo: "ok" | "error"; texto: string } | null>(null);

  // Cargar pacientes activos al abrir la página.
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/pacientes");
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "No se pudieron cargar los pacientes.");
        setPacientes(data.pacientes);
      } catch (e) {
        setErrorCarga(e instanceof Error ? e.message : "Error al cargar pacientes.");
      } finally {
        setCargando(false);
      }
    })();
  }, []);

  // Coincidencias del buscador (máximo 8 para no saturar).
  const coincidencias = useMemo(() => {
    const q = busqueda.trim().toLowerCase();
    if (!q || seleccionado) return [];
    return pacientes
      .filter((p) => p.nombre.toLowerCase().includes(q) || p.dni.includes(q))
      .slice(0, 8);
  }, [busqueda, pacientes, seleccionado]);

  const listo = seleccionado && piso && silla.trim() && turno;

  async function registrar() {
    if (!listo || !seleccionado) return;
    setEnviando(true);
    setMensaje(null);
    try {
      const res = await fetch("/api/asignar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          pacienteId: seleccionado.id,
          piso,
          silla: silla.trim(),
          turno,
          comentario,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "No se pudo registrar la asignación.");

      setMensaje({
        tipo: "ok",
        texto: `Asignación registrada: ${seleccionado.nombre} → Piso ${piso}, Silla ${silla}, Turno ${turno}.`,
      });
      // Limpiar para la siguiente asignación.
      setSeleccionado(null);
      setBusqueda("");
      setSilla("");
      setTurno("");
      setComentario("");
      // Piso se conserva: es común asignar varias seguidas en la misma sala.
    } catch (e) {
      setMensaje({ tipo: "error", texto: e instanceof Error ? e.message : "Error al registrar." });
    } finally {
      setEnviando(false);
    }
  }

  return (
    <main style={{ maxWidth: 560, margin: "0 auto", padding: "32px 20px", fontFamily: "Inter, system-ui, sans-serif" }}>
      <h1 style={{ fontSize: 24, fontWeight: 700, color: "hsl(231 48% 48%)", marginBottom: 4 }}>
        Asignación de sala
      </h1>
      <p style={{ color: "hsl(240 4% 46%)", fontSize: 14, marginTop: 0, marginBottom: 28 }}>
        Busca al paciente, elige piso, silla y turno, y registra la asignación.
      </p>

      {errorCarga && (
        <div style={banner("error")}>{errorCarga}</div>
      )}

      {/* Paso 1: paciente */}
      <label style={lbl}>Paciente</label>
      {seleccionado ? (
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", border: "2px solid hsl(231 48% 48%)", borderRadius: 8, padding: "10px 14px", marginBottom: 18 }}>
          <div>
            <div style={{ fontWeight: 600 }}>{seleccionado.nombre}</div>
            <div style={{ fontSize: 12, color: "hsl(240 4% 46%)" }}>
              DNI {seleccionado.dni}{seleccionado.turno ? ` · Turno habitual ${seleccionado.turno}` : ""}{seleccionado.filtro ? ` · ${seleccionado.filtro}` : ""}
            </div>
          </div>
          <button onClick={() => setSeleccionado(null)} style={btnGhost}>Cambiar</button>
        </div>
      ) : (
        <div style={{ position: "relative", marginBottom: 18 }}>
          <input
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            placeholder={cargando ? "Cargando pacientes…" : "Escribe nombre o DNI…"}
            disabled={cargando}
            style={input}
          />
          {coincidencias.length > 0 && (
            <div style={{ position: "absolute", top: "100%", left: 0, right: 0, background: "white", border: "1px solid hsl(240 6% 90%)", borderRadius: 8, marginTop: 4, boxShadow: "0 8px 24px rgba(0,0,0,.12)", zIndex: 10, overflow: "hidden" }}>
              {coincidencias.map((p) => (
                <div
                  key={p.id}
                  onClick={() => { setSeleccionado(p); setBusqueda(""); }}
                  style={{ padding: "10px 14px", cursor: "pointer", borderBottom: "1px solid hsl(240 6% 95%)" }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "hsl(240 8% 96%)")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "white")}
                >
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{p.nombre}</div>
                  <div style={{ fontSize: 12, color: "hsl(240 4% 46%)" }}>DNI {p.dni}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Paso 2: piso y silla */}
      <div style={{ display: "flex", gap: 12, marginBottom: 18 }}>
        <div style={{ flex: 1 }}>
          <label style={lbl}>Piso / Sala</label>
          <select value={piso} onChange={(e) => setPiso(e.target.value)} style={input}>
            <option value="">Seleccionar…</option>
            {PISOS.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>
        <div style={{ flex: 1 }}>
          <label style={lbl}>Silla (número)</label>
          <input value={silla} onChange={(e) => setSilla(e.target.value.replace(/[^0-9A-Za-z]/g, ""))} placeholder="Ej. 7" style={input} />
        </div>
      </div>

      {/* Paso 3: turno */}
      <label style={lbl}>Turno</label>
      <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
        {TURNOS.map((t) => (
          <button
            key={t}
            onClick={() => setTurno(t)}
            style={{
              flex: 1, padding: "10px 0", borderRadius: 8, cursor: "pointer", fontWeight: 700, fontSize: 15,
              border: turno === t ? "2px solid hsl(231 48% 48%)" : "1px solid hsl(240 6% 85%)",
              background: turno === t ? "hsl(231 48% 96%)" : "white",
              color: turno === t ? "hsl(231 48% 48%)" : "hsl(240 10% 30%)",
            }}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Comentario opcional */}
      <label style={lbl}>Comentario (opcional)</label>
      <textarea value={comentario} onChange={(e) => setComentario(e.target.value)} rows={2} placeholder="Observaciones…" style={{ ...input, resize: "vertical" }} />

      <button
        onClick={registrar}
        disabled={!listo || enviando}
        style={{
          width: "100%", marginTop: 20, padding: "13px 0", borderRadius: 8, border: "none",
          fontWeight: 700, fontSize: 15, cursor: listo && !enviando ? "pointer" : "not-allowed",
          background: listo && !enviando ? "hsl(231 48% 48%)" : "hsl(240 6% 80%)", color: "white",
        }}
      >
        {enviando ? "Registrando…" : "Registrar asignación"}
      </button>

      {mensaje && (
        <div style={{ ...banner(mensaje.tipo), marginTop: 18 }}>{mensaje.texto}</div>
      )}
    </main>
  );
}

// --- estilos reutilizables ---
const lbl: React.CSSProperties = { display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 };
const input: React.CSSProperties = {
  width: "100%", padding: "10px 12px", borderRadius: 8, border: "1px solid hsl(240 6% 85%)",
  fontSize: 14, fontFamily: "inherit", boxSizing: "border-box", background: "white",
};
const btnGhost: React.CSSProperties = {
  border: "none", background: "transparent", color: "hsl(231 48% 48%)", fontWeight: 600, cursor: "pointer", fontSize: 13,
};
function banner(tipo: "ok" | "error"): React.CSSProperties {
  return {
    padding: "12px 14px", borderRadius: 8, fontSize: 14,
    background: tipo === "ok" ? "hsl(145 63% 95%)" : "hsl(0 84% 96%)",
    color: tipo === "ok" ? "hsl(145 63% 25%)" : "hsl(0 70% 40%)",
    border: `1px solid ${tipo === "ok" ? "hsl(145 63% 80%)" : "hsl(0 84% 88%)"}`,
  };
}
