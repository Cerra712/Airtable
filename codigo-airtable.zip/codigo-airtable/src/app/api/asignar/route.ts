// src/app/api/asignar/route.ts
// POST /api/asignar -> crea un registro en ASIGNACION EN SALA.
// Body JSON: { pacienteId, piso, silla, turno, comentario? }
import { NextResponse } from "next/server";
import { crearAsignacion, PISOS, TURNOS, type NuevaAsignacion } from "@/lib/airtable";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Partial<NuevaAsignacion>;

    // Validación básica del lado del servidor.
    if (!body.pacienteId) {
      return NextResponse.json({ error: "Falta seleccionar el paciente." }, { status: 400 });
    }
    if (!body.piso || !PISOS.includes(body.piso)) {
      return NextResponse.json({ error: "Piso inválido." }, { status: 400 });
    }
    if (!body.silla || !String(body.silla).trim()) {
      return NextResponse.json({ error: "Falta el número de silla." }, { status: 400 });
    }
    if (!body.turno || !TURNOS.includes(body.turno)) {
      return NextResponse.json({ error: "Turno inválido (debe ser A, B o C)." }, { status: 400 });
    }

    const result = await crearAsignacion({
      pacienteId: body.pacienteId,
      piso: body.piso,
      silla: String(body.silla).trim(),
      turno: body.turno,
      comentario: body.comentario,
    });

    return NextResponse.json({ ok: true, id: result.id });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Error desconocido";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
