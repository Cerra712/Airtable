// src/app/api/pacientes/route.ts
// GET /api/pacientes -> lista de pacientes ACTIVOS para el desplegable.
import { NextResponse } from "next/server";
import { getPacientesActivos } from "@/lib/airtable";

export const dynamic = "force-dynamic"; // siempre datos frescos

export async function GET() {
  try {
    const pacientes = await getPacientesActivos();
    return NextResponse.json({ pacientes });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Error desconocido";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
